package org.springDemoXmlConfiguration.v1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("BeansV1.xml");

        // ======== далее мы можем НЕ СОЗДАВАТЬ самостоятельно экземпляры классов, а использовать те ссылки которые spring уже создал =====

        HelloWorld objA = (HelloWorld) context.getBean("helloWorld");

        System.out.println(objA);


        HelloWorld objB = (HelloWorld) context.getBean("helloWorld");

        System.out.println(objB);

        System.out.println("После замены значения в поле message: ");
        objB.setMessage("Новый текст");

        System.out.println(objA.getMessage());
        System.out.println(objB.getMessage());

    }
}
