package org.lesson1ProjectWithSpring.back.service.validation.validationRules;

import org.lesson1ProjectWithSpring.back.dto.RequestDto;

public interface ValidationRule {

    void validate(RequestDto request);
}
