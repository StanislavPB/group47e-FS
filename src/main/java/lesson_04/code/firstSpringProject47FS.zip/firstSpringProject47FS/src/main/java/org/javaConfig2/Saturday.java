package org.javaConfig2;

public class Saturday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Saturday";
    }
}
