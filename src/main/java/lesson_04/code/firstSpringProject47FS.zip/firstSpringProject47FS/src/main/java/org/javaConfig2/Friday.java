package org.javaConfig2;

public class Friday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Friday";
    }
}
