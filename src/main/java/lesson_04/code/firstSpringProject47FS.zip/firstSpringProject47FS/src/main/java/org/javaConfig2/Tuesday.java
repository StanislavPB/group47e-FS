package org.javaConfig2;

public class Tuesday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Tuesday";
    }
}
