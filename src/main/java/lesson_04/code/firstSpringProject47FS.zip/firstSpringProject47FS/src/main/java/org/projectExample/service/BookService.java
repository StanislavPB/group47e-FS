package org.projectExample.service;

import org.projectExample.entity.Book;
import org.projectExample.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BookService {

    @Autowired
    private BookRepository repository;


    public void addNewBook(String title, String author){

        if (!title.isBlank() && !author.isBlank()){
            Book book = new Book(title,author);
            repository.add(book);
            System.out.println("книга добавлена успешно");
        } else {
            System.out.println("книгу добавить не удалось");
        }
    }

    public void printBookData() {
        repository.printBooks();
    }
}
