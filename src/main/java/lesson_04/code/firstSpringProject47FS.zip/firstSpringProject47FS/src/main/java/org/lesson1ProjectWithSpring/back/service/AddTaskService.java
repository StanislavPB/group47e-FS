package org.lesson1ProjectWithSpring.back.service;

import org.lesson1ProjectWithSpring.back.dto.RequestDto;
import org.lesson1ProjectWithSpring.back.dto.ResponseDto;
import org.lesson1ProjectWithSpring.back.entity.Task;
import org.lesson1ProjectWithSpring.back.repository.InMemoryRepository;
import org.lesson1ProjectWithSpring.back.service.validation.ValidationService;
import org.lesson1ProjectWithSpring.back.service.validation.validationRules.CoreError;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AddTaskService {

    private final InMemoryRepository repository;
    private final ValidationService validationService;

    public AddTaskService(InMemoryRepository repository, ValidationService validationService) {
        this.repository = repository;
        this.validationService = validationService;
    }


    public ResponseDto<Task> addNewTask(RequestDto request) {
        // пока что вместо лога используем печать на экран
        System.out.println("Receive request: " + request);

        // валидация данных

        List<CoreError> errors = validationService.validation(request);
        Task savedTask = null;

        if (errors.isEmpty()) {
            Task taskForSave = new Task(0, request.getTaskName(), request.getTaskDescription());
            savedTask = repository.add(taskForSave);
        }

        return new ResponseDto<>(savedTask,errors);

    }

}
