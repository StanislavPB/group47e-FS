package org.javaConfig2;

public class Wednesday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Wednesday";
    }
}
