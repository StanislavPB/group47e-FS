package org.springDemoXmlConfiguration.v2;

public class HelloWorld {

   public void initMethod() {
       System.out.println("Я инит-метод ...");
   }

    public void destroyMethod() {
        System.out.println("Я destroy-метод ...");
    }

    public void workingMethod() {
        System.out.println("Working ...");
    }


}
