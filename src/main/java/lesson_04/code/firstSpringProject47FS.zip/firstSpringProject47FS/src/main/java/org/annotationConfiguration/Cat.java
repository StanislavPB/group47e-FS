package org.annotationConfiguration;

import org.springframework.stereotype.Component;

@Component
public class Cat {

    private String name = "Barsik";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Cat() {
        System.out.println("Cat constructor ... ");
    }

    @Override
    public String toString() {
        return "Cat{" +
                "name='" + name + '\'' +
                '}';
    }
}
