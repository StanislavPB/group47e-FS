package org.annotationConfiguration;

import org.springframework.stereotype.Component;

@Component
public class HomeAnimalService {

    private final Dog dog;

    public HomeAnimalService(Dog dog) {
        this.dog = dog;
    }

    public void printDogData() {
        System.out.println("Dog's name: " + dog.getName());
    }
}
