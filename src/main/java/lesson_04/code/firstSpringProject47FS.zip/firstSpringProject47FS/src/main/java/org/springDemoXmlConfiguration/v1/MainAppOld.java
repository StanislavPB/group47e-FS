package org.springDemoXmlConfiguration.v1;

public class MainAppOld {
    public static void main(String[] args) {
        HelloWorld helloWorld = new HelloWorld("New text");

        System.out.println(helloWorld.getMessage());

    }
}
