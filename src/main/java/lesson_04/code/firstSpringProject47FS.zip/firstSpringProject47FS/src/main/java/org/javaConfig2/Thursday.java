package org.javaConfig2;

public class Thursday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Thursday";
    }
}
