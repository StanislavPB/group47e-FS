package org.lesson1ProjectWithSpring.back.service.validation;

import org.lesson1ProjectWithSpring.back.dto.RequestDto;
import org.lesson1ProjectWithSpring.back.service.validation.validationRules.CoreError;
import org.lesson1ProjectWithSpring.back.service.validation.validationRules.ValidationRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ValidationService {

    private List<ValidationRule> validationRules;

    public ValidationService(List<ValidationRule> validationRules) {
        this.validationRules = validationRules;
    }

    public List<CoreError> validation(RequestDto request){
        List<CoreError> errors = new ArrayList<>();

        if (request == null) {
            errors.add(new CoreError("Task request must be not null"));
            return errors;
        }

        for (ValidationRule rule : validationRules){
           try {
               rule.validate(request);
           } catch (ValidationException e) {
               errors.add(new CoreError(e.getMessage()));
           }
        }


        return errors;
    }

}
