package org.javaConfig2;

public class Sunday implements WeekDay{
    @Override
    public String getWeekDay() {
        return "Sunday";
    }
}
