package org.lesson1ProjectWithSpring.back.config;

import org.lesson1ProjectWithSpring.back.service.validation.validationRules.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class AppConfig {

    @Bean("validationRule")
    List<ValidationRule> validationRules(){
        List<ValidationRule> validationRules = new ArrayList<>();
        validationRules.add(new TaskNameMaxLengthValidation());
        validationRules.add(new TaskNameMinLengthValidation());
        validationRules.add(new TaskNameNullValidation());
        validationRules.add(new TaskDescriptionNullValidation());

        return validationRules;
    }

}
