package org.javaConfig2;

public interface WeekDay {

    String getWeekDay();

}
