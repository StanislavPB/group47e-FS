package org.workingproject47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkingProject47fsApplication {

    public static void main(String[] args) {
        SpringApplication.run(WorkingProject47fsApplication.class, args);
    }

}
