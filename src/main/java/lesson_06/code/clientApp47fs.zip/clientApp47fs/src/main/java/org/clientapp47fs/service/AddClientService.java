package org.clientapp47fs.service;

import lombok.RequiredArgsConstructor;
import org.clientapp47fs.dto.RequestAddClientDto;
import org.clientapp47fs.entity.Client;
import org.clientapp47fs.repository.ClientRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AddClientService {

    private final ClientRepository repository;


    public Integer addClient(RequestAddClientDto request){

        Client clientForAdd = new Client(0, request.getName(), request.getEmail(), request.getPassword());

        return repository.add(clientForAdd);
    }
}
