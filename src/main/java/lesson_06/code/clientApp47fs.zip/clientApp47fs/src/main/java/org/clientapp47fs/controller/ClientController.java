package org.clientapp47fs.controller;

import lombok.RequiredArgsConstructor;
import org.clientapp47fs.dto.RequestAddClientDto;
import org.clientapp47fs.dto.ResponseDto;
import org.clientapp47fs.entity.Client;
import org.clientapp47fs.service.AddClientService;
import org.clientapp47fs.service.DeleteClientService;
import org.clientapp47fs.service.FindClientService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/clients")
public class ClientController {

    private final AddClientService addClientService;
    private final FindClientService findClientService;
    private final DeleteClientService deleteClientService;


    /*
    localhost:8080/api/clients - get запрос

    localhost:8080/api/clients/addNew - post запрос

    localhost:8080/api/clients/3 get запрос, где 3 - это порядковый номер клиента
    этот номер может меняться, то есть по сути 3 - id
    localhost:8080/api/clients/4
    localhost:8080/api/clients/7
    localhost:8080/api/clients/10

    localhost:8080/api/clients/findByName?clientNAme=James - get запрос поиска по имени клиента

     */

    @GetMapping()
    // localhost:8080/clients
    public List<ResponseDto> findAll(){
        return findClientService.findAll();
    }


    @PostMapping("/addNew")
    public Integer addNew(@RequestBody RequestAddClientDto request){
        /*
        {
        "name" : "client1",
        "email" : "client1@company.com",
        "password" : "Qwerty"
        }
         */
        return addClientService.addClient(request);
    }

    @GetMapping("/{clientId}")
    //localhost:8080/api/clients/3
    public Optional<Client> findById(@PathVariable(name = "clientId") Integer id){
        return findClientService.findById(id);
    }

    @GetMapping("/findByName")
    //localhost:8080/api/clients/findByName?clientName=James
    public List<Client> findByName(@RequestParam(name = "clientName") String name){
        return findClientService.findByName(name);
    }

    @GetMapping("/findByEmail")
    //localhost:8080/api/clients/findByEmail?email=James@company.com
    public Optional<Client> findByEmail(@RequestParam(name = "email") String email){
        return findClientService.findByemail(email);
    }

    @DeleteMapping("/{id}")
    // localhost:8080/clients/{id}
    public boolean deleteClient(@PathVariable Integer id){
        return deleteClientService.deleteClient(id);
    }

}
