package org.clientapp47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientApp47fsApplicationTests {

    @Test
    void contextLoads() {
    }

}
