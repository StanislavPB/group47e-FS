package org.clientapp47fs.service;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.clientapp47fs.repository.ClientRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DeleteClientService {

    private final ClientRepository repository;

    public boolean deleteClient(Integer id) {
        return repository.deleteById(id);
    }
}
