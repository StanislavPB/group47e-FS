package org.clientapp47fs.service;

import lombok.RequiredArgsConstructor;
import org.clientapp47fs.dto.ResponseDto;
import org.clientapp47fs.entity.Client;
import org.clientapp47fs.repository.ClientRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FindClientService {

    private final ClientRepository repository;

    public List<ResponseDto> findAll() {
        List<Client> allClients = repository.findAll();
        List<ResponseDto> responseDtos = new ArrayList<>();
        for (Client client : allClients){
            responseDtos.add(new ResponseDto(client.getId(), client.getName(), client.getEmail()));
        }

        return responseDtos;
    }

    public Optional<Client> findById(Integer id){
        return repository.findById(id);
    }


    public List<Client> findByName(String name){
        return repository.findByName(name);
    }

    public Optional<Client> findByemail(String email){
        return repository.findByEmail(email);
    }
}
