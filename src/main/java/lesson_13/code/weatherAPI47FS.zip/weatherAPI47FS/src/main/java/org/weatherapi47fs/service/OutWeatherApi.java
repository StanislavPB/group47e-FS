package org.weatherapi47fs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.weatherapi47fs.dto.WeatherJSON;
import org.weatherapi47fs.entity.WeatherDataEntity;
import org.weatherapi47fs.service.postExample.RequestObj;
import org.weatherapi47fs.service.postExample.ResponseObj;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.Collections;

@Service
@RequiredArgsConstructor
@Slf4j
public class OutWeatherApi {

    private final String KEY = "23f988ac0fc24f2e87c9360fd677ebb7";

    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    public WeatherDataEntity receiveDataFromWeatherApi(String lat, String lon) throws MalformedURLException, URISyntaxException {

        // https://api.weatherbit.io/v2.0/current?lat=35.7796&lon=-78.6382&key=API_KEY

//        String urlRequest = "https://api.weatherbit.io/v2.0/current";
//        urlRequest = urlRequest + "?lat=" + lat;
//        urlRequest = urlRequest + "&lon=" + lon;
//        urlRequest = urlRequest + "&key=" + KEY;

        String urlRequest = createUrl(lat, lon);
        URL url = new URL(urlRequest);

        log.info("Sending request to {}", url);
        ResponseEntity<WeatherJSON> receivedFromApi = restTemplate().getForEntity(url.toURI(), WeatherJSON.class);
        log.info("Received response {}", receivedFromApi);

        if (receivedFromApi.getBody() != null) {
            String tempFromResponse = "" + receivedFromApi.getBody().getData().get(0).getTemp();
            return new WeatherDataEntity(0,lat,lon, tempFromResponse, LocalDateTime.now());
        } else {
            throw new IllegalArgumentException("Response body not found");
        }

    }

    private String createUrl(String lat, String lon) {
        return UriComponentsBuilder.fromHttpUrl("https://api.weatherbit.io/v2.0/current")
                .queryParam("lat", lat)
                .queryParam("lon", lon)
                .queryParam("key", KEY)
                .build()
                .toString();
    }

    public void sendPostRequest() throws MalformedURLException {

        String urlRequest = "http://mysite.com/api/resource";
        URL url = new URL(urlRequest);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        RequestObj requestObj = new RequestObj("str1","str2");

        HttpEntity<RequestObj> httpEntity = new HttpEntity<>(requestObj,headers);

        try {
            ResponseEntity<ResponseObj> response = restTemplate().exchange(urlRequest, HttpMethod.POST, httpEntity, ResponseObj.class);

            if (response.getBody() != null){
                // что-то делаем с этим ответом
            } else {
                // как-то реагируем на пустой ответ
            }
        } catch (HttpClientErrorException e) {
            // обработка exception
        }


    }
}
