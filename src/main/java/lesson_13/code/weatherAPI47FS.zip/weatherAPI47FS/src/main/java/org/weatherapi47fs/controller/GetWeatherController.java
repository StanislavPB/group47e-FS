package org.weatherapi47fs.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.weatherapi47fs.dto.WeatherRequestDto;
import org.weatherapi47fs.dto.WeatherResponseDto;
import org.weatherapi47fs.service.WeatherDataService;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class GetWeatherController {

    private final WeatherDataService service;

    @GetMapping("/weather")
    public WeatherResponseDto getWeather(@RequestParam String lat, @RequestParam String lon) throws MalformedURLException, URISyntaxException {

        return service.getWeather(new WeatherRequestDto(lat,lon));
    }
}
