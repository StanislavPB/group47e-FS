package org.weatherapi47fs.service.postExample;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestObj {

    private String field1;
    private String field2;

}
