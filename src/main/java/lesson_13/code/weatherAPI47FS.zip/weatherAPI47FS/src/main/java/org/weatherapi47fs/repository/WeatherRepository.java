package org.weatherapi47fs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.weatherapi47fs.entity.WeatherDataEntity;
import java.util.Optional;

public interface WeatherRepository extends JpaRepository<WeatherDataEntity, Integer> {

    Optional<WeatherDataEntity> findByLatitudeAndLongitudeOrderByCreateTimeDesc(String lat, String lon);

//    @Query("SELECT w FROM weather w WHERE w.latilude = :lat AND w.longitude = :lon ORDER BY w.createTime DESC ")
//    Optional<WeatherDataEntity> findLatestByLatitudeAndLongitude(@Param("lat") String lat, @Param("lon") String lon);
}
