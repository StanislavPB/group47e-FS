package org.weatherapi47fs.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WeatherRequestDto {
    private String latitude;
    private String longitude;
}
