package org.weatherapi47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherApi47FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
