package org.weatherapi47fs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.weatherapi47fs.dto.WeatherRequestDto;
import org.weatherapi47fs.dto.WeatherResponseDto;
import org.weatherapi47fs.entity.WeatherDataEntity;
import org.weatherapi47fs.repository.WeatherRepository;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class WeatherDataService {

    private final WeatherRepository repository;
    private final OutWeatherApi outWeatherApi;

    private final Integer EXPIRATION_TIME = 1;


    public WeatherResponseDto getWeather(WeatherRequestDto request) throws MalformedURLException, URISyntaxException {
        Optional<WeatherDataEntity> dataFromDb = repository.findByLatitudeAndLongitudeOrderByCreateTimeDesc(request.getLatitude(), request.getLongitude());

        if (checkDatabaseRecord(dataFromDb)) {
            WeatherDataEntity currentWeatherFromDatabase = dataFromDb.get();
            return new WeatherResponseDto(
                    currentWeatherFromDatabase.getLatitude(),
                    currentWeatherFromDatabase.getLongitude(),
                    currentWeatherFromDatabase.getTemp()
            );
        }

        WeatherDataEntity currentWeatherFromApi = outWeatherApi.receiveDataFromWeatherApi(request.getLatitude(), request.getLongitude());

        repository.save(currentWeatherFromApi);

        return new WeatherResponseDto(
                currentWeatherFromApi.getLatitude(),
                currentWeatherFromApi.getLongitude(),
                currentWeatherFromApi.getTemp()
        );


    }

    private boolean checkDatabaseRecord(Optional<WeatherDataEntity> dataForCheck){
        if (dataForCheck.isEmpty()) return false;

        WeatherDataEntity databaseRecord = dataForCheck.get();
        LocalDateTime createdTime = databaseRecord.getCreateTime();

        long duration = Duration.between(createdTime, LocalDateTime.now()).toMinutes();

        //log.info("duration {}", duration);
        return duration <= EXPIRATION_TIME;
    }

}
