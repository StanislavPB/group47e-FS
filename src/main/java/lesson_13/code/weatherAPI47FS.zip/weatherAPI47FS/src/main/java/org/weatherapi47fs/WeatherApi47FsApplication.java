package org.weatherapi47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherApi47FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherApi47FsApplication.class, args);
    }

}
