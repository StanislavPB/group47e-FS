package org.weatherapi47fs.service.postExample;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseObj {

    private String responseField1;
    private String responseField2;

}
