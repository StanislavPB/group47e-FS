package org.demo47fsemail;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository repository;
    private final EmailService emailService;

    public void registerUser(String email) {

//        User user = new User();
//        user.setEmail(email);
//        user.setConfirmed(false);
//
//        // user.setConfirmationCode("code");
//        user.setConfirmationCode(UUID.randomUUID().toString());
//
       /*  UUID - universal uniq identifier
       128-bit

       формат 8-4-4-4-12
       123a4567-e89d-12d3-efgh-456789012345
       UUID.randomUUID()
        */

        User user = User.builder()
                .email(email)
                .confirmationCode(UUID.randomUUID().toString())
                .isConfirmed(false)
                .build();

        repository.save(user);

        // отправка email с confirmation Code

        emailService.sendConfirmationCodeByEmail(user);

    }

    public boolean confirmUser(String confirmationCode){
        Optional<User> userOptional = repository.findByConfirmationCode(confirmationCode);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setConfirmed(true);
            repository.save(user);
            return true;
        }

        return false;
    }
}
