package org.demo47fsemail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo47FsEmailApplicationTests {

    @Test
    void contextLoads() {
    }

}
