package org.demo47fsemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo47FsEmailApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo47FsEmailApplication.class, args);
    }

}
