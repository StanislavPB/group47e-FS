package org.demo47fsemail;

import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Async
    public void sendConfirmationCodeByEmail(User user){

        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom("javalessons2024@gmail.com");
        mailMessage.setTo(user.getEmail());
        mailMessage.setSubject("Registration confirmation code");
        mailMessage.setText("Please confirm your registration with code: " + user.getConfirmationCode());

        mailSender.send(mailMessage);
    }
}
