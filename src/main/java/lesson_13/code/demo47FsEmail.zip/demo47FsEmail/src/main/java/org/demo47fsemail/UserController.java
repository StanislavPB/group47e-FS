package org.demo47fsemail;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/registration")
    public ResponseEntity<String> registerUser(@RequestParam String email) {
        userService.registerUser(email);
        return ResponseEntity.ok("Registration initiated. Check your email for confirmation code");
    }


    @PostMapping("/confirmation")
    public ResponseEntity<String> confirmUser(@RequestParam String code) {
        if (userService.confirmUser(code)) {
            return ResponseEntity.ok("User confirmed successfully.");
        } else {
            return ResponseEntity.badRequest().body("Invalid confirmation code");
        }
    }

}
