package org.workingproject47fs.entity;

public enum TaskStatus {
    OPEN,
    CLOSE,
    PROGRESS
}
