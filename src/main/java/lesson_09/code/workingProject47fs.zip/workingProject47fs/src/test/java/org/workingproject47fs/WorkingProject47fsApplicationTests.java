package org.workingproject47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkingProject47fsApplicationTests {

    @Test
    void contextLoads() {
    }

}
