package org.demospringsecuritythymeleafapp47fs.controller;

import lombok.AllArgsConstructor;
import org.demospringsecuritythymeleafapp47fs.dto.UserRegistrationDto;
import org.demospringsecuritythymeleafapp47fs.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/registration")
@AllArgsConstructor
public class RegistrationController {

    private UserService userService;

    @ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto() {
        return new UserRegistrationDto();
    }

    @GetMapping
    public String showRegistrationForm() { return "registration";}

    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") UserRegistrationDto registrationDto){
        try {
            userService.save(registrationDto);
        } catch (Exception e){
            System.out.println(e.getMessage());
            return "redirect:/registration?email_invalid";
        }

        return "redirect:/registration?success";
    }
}
