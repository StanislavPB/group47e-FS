package org.demospringsecuritythymeleafapp47fs.service;

import lombok.RequiredArgsConstructor;
import org.demospringsecuritythymeleafapp47fs.dto.UserRegistrationDto;
import org.demospringsecuritythymeleafapp47fs.entity.Role;
import org.demospringsecuritythymeleafapp47fs.entity.User;
import org.demospringsecuritythymeleafapp47fs.repository.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService implements UserDetailsService {

    private final UserRepository repository;
    private final RoleService roleService;

    public User save(UserRegistrationDto registrationDto){

        Role defaultRole = roleService.findByRoleName("USER");

        User user = new User(
                registrationDto.getFirstName(),
                registrationDto.getLastName(),
                registrationDto.getEmail(),
                registrationDto.getPassword(),
                Arrays.asList(defaultRole)
        );

        return user;
    }

    public List<User> getAll() {
        return repository.findAll();
    }


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
       Optional<User> userOptional = repository.findByEmail(email);

       if (userOptional.isEmpty()) {
           throw new UsernameNotFoundException("Invalid username");
       }

       User user = userOptional.get();
       // возвращаем реализацию интерфейса userDetails в виде экземпляроа класса user из библиотеки spring security

       return new org.springframework.security.core.userdetails.User(
               user.getEmail(), // анлог login
               user.getPassword(),
               // нужно добавить роли
               mapRolesToAuthorities(user.getRoles())
       );


    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.getName()))
                .toList();
    }
}
