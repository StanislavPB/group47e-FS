package org.demospringsecuritythymeleafapp47fs.service;

import lombok.RequiredArgsConstructor;
import org.demospringsecuritythymeleafapp47fs.entity.Role;
import org.demospringsecuritythymeleafapp47fs.repository.RoleRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository repository;

    public Role findByRoleName(String role){
        return repository.findByName(role);
    }
}
