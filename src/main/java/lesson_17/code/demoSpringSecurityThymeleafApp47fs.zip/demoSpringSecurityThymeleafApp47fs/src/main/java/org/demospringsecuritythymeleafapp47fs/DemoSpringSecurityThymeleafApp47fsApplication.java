package org.demospringsecuritythymeleafapp47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringSecurityThymeleafApp47fsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSpringSecurityThymeleafApp47fsApplication.class, args);
    }

}
