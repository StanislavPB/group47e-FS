package org.demospringsecuritythymeleafapp47fs.repository;

import org.demospringsecuritythymeleafapp47fs.entity.Role;
import org.demospringsecuritythymeleafapp47fs.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role,Long> {
    Role findByName(String name);
}
