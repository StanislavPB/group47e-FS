package org.demospringsecuritythymeleafapp47fs.dto;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.demospringsecuritythymeleafapp47fs.entity.Role;

import java.util.Collection;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRegistrationDto {

    private String firstName;
    private String lastName;
    private String email;
    private String password;

}
