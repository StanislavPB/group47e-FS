package org.springsecuritydemo47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDemo47fsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityDemo47fsApplication.class, args);
    }

}
