package org.springsecuritydemo47fs.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springsecuritydemo47fs.entity.MyUser;
import org.springsecuritydemo47fs.repository.MyUserRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

    private final MyUserRepository repository;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<MyUser> myUserOptional = repository.findByLogin(username);

        if (myUserOptional.isEmpty()) {
            throw new UsernameNotFoundException("Unknown user: " + username);
        }

        MyUser myUser = myUserOptional.get();

        UserDetails userDetails = User.builder()
                .username(myUser.getLogin())
                .password(myUser.getPassword())
                .roles(myUser.getRole())
                .build();

        log.info("User login attempt: {}", myUser.getLogin());
        log.info("User role attempt: {}", myUser.getRole());
        log.info("User details attempt: {}", userDetails);

        return userDetails;
    }
}
