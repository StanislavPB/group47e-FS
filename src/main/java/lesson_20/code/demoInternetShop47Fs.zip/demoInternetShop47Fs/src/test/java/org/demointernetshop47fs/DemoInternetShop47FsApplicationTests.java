package org.demointernetshop47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoInternetShop47FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
