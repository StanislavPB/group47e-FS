package org.demointernetshop47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoInternetShop47FsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoInternetShop47FsApplication.class, args);
    }

}
