package org.springbootjpa.repository;

import org.springbootjpa.entity.ToDoEntity;

import java.util.List;

public interface ToDoRepositoryInMemory {

    ToDoEntity add(ToDoEntity entity);

    List<ToDoEntity> findAll();

    List<ToDoEntity> findByName(String name);

}
