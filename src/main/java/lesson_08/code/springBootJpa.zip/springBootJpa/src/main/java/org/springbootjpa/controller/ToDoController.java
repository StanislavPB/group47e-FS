package org.springbootjpa.controller;

import lombok.RequiredArgsConstructor;
import org.springbootjpa.dto.AddToDoRequest;
import org.springbootjpa.entity.ToDoEntity;
import org.springbootjpa.service.AddToDoService;
import org.springbootjpa.service.FindToDoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
@RequiredArgsConstructor
public class ToDoController {

    private final AddToDoService addToDoService;
    private final FindToDoService findToDoService;

    @PostMapping
    public ToDoEntity add(@RequestBody AddToDoRequest request) {
        return addToDoService.add(request);
    }

    @GetMapping
    public List<ToDoEntity> findAll() {
        return findToDoService.findAll();
    }


    @GetMapping("/name")
    public List<ToDoEntity> findByName(@RequestParam String name) {
        return findToDoService.findByName(name);
    }


    @GetMapping("/{id}")
    public ToDoEntity findById(@PathVariable Integer id) {
        return findToDoService.findById(id);
    }
}
