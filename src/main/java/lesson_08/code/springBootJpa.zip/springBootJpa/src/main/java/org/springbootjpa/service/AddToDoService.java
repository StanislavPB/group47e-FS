package org.springbootjpa.service;

import lombok.RequiredArgsConstructor;
import org.springbootjpa.dto.AddToDoRequest;
import org.springbootjpa.entity.ToDoEntity;
import org.springbootjpa.repository.ToDoRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AddToDoService {

    public final ToDoRepository repository;

    public ToDoEntity add(AddToDoRequest request){
        System.out.println("Received request: " + request);
        ToDoEntity entity = new ToDoEntity();
        entity.setName(request.getName());
        entity.setDescription(request.getDescription());
        ToDoEntity savedEntity = repository.save(entity);

        return savedEntity;
    }

}
