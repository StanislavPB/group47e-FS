package org.springbootjpa.service;

import lombok.RequiredArgsConstructor;
import org.springbootjpa.entity.ToDoEntity;
import org.springbootjpa.repository.ToDoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FindToDoService {

    private final ToDoRepository repository;

    public List<ToDoEntity> findAll() {
       return repository.findAll();
    }

    public List<ToDoEntity> findByName(String name) {
        return repository.findByName(name);
    }

    public ToDoEntity findById(Integer id){
        Optional<ToDoEntity> optionalToDoEntity = repository.findById(id);
        if (optionalToDoEntity.isPresent()) {
            return optionalToDoEntity.get();
        } else {
            throw new IllegalArgumentException("Entity with ID = " + id + " not found");
        }
    }
}
