package org.firstspringbootapp47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootApp47FsApplicationTests {

    @Test
    void contextLoads() {
    }

}
