package org.firstspringbootapp47fs;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class HelloWorldController {

    @GetMapping("/greeting")
    public String helloWorldController(Model model) {

        String nameVariable = "Ruslan";

        model.addAttribute("name1", nameVariable);

        model.addAttribute("name3", "У НАС ВСЕ ХОРОШО!!!");

        return "greeting";
    }

}
