package org.consultationdemoproject.controller;

import lombok.RequiredArgsConstructor;
import org.consultationdemoproject.dto.ProductDto;
import org.consultationdemoproject.entity.Product;
import org.consultationdemoproject.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService service;

    @PostMapping("/newProduct")
    public ResponseEntity<Product> addNewProduct(@RequestBody ProductDto request){

        return new ResponseEntity<>(service.addProduct(request), HttpStatus.CREATED);
    }


    @GetMapping("/all")
    public ResponseEntity<List<Product>> findAll(){
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> findById(@PathVariable Integer id){

        Optional<Product> findOpt = service.findById(id);

        if (findOpt.isPresent()) {
        return new ResponseEntity<>(service.findById(id).get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }


}
