package org.consultationdemoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationDemoProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
