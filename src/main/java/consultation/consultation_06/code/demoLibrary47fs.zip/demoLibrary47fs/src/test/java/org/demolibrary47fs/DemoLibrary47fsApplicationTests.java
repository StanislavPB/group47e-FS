package org.demolibrary47fs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoLibrary47fsApplicationTests {

    @Test
    void contextLoads() {
    }

}
