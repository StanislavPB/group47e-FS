package org.demolibrary47fs.service;

import lombok.RequiredArgsConstructor;
import org.demolibrary47fs.dto.BookRequestDto;
import org.demolibrary47fs.entity.Author;
import org.demolibrary47fs.entity.Book;
import org.demolibrary47fs.entity.Genre;
import org.demolibrary47fs.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository repository;
    private final AuthorService authorService;
    private final GenreService genreService;
    private final BookRepository bookRepository;


    // создать новую книгу

    public Book createBook(BookRequestDto request){

        Author author = authorService.findAuthorByName(request.getAuthor());

        List<Genre> genres = genreService.findGenresByName(request.getGenres());

        Book newBook = Book.builder()
                .title(request.getTitle())
                .isIssued(false)
                .author(author)
                .genres(genres)
                .build();

        Book savedBook = bookRepository.save(newBook);

        return savedBook;
    }

}
