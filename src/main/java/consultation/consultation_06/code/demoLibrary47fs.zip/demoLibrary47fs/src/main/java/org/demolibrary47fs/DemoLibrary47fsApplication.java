package org.demolibrary47fs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLibrary47fsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoLibrary47fsApplication.class, args);
    }

}
