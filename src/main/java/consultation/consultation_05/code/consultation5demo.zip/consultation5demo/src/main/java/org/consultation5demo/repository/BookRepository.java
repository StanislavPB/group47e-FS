package org.consultation5demo.repository;

import org.consultation5demo.entity.Author;
import org.consultation5demo.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BookRepository extends JpaRepository<Book,Integer> {

    Optional<Book> findByTitle(String title);

    List<Book> findByAuthor(Author author);

}
