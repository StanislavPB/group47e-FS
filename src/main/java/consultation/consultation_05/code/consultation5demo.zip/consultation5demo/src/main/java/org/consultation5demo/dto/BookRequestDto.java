package org.consultation5demo.dto;

import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.consultation5demo.entity.Author;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookRequestDto {

    private String title;
    private String author;
    private String description;

}
