package org.consultation5demo.service;

import lombok.RequiredArgsConstructor;
import org.consultation5demo.dto.AuthorRequestDto;
import org.consultation5demo.entity.Author;
import org.consultation5demo.repository.AuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthorService {
    private final AuthorRepository repository;

    // создание автора
    public Author createAuthor(AuthorRequestDto request) {
        Author author = Author.builder()
                .name(request.getName())
                .build();

        return repository.save(author);
    }

    public Author getAuthorById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Автор с id: " + id + " не найден"));
    }


    public Author getAuthorByName(String name) {
        return repository.findByName(name)
                .orElseThrow(() -> new RuntimeException("Автор с name: " + name + " не найден"));
    }

    public List<Author> getAllAuthors() {
        return repository.findAll();
    }

    public void deleteAuthorById(Integer id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("Author with id: " + id + " not found");
        }
    }
}
