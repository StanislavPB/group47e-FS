package org.jdbcdemo47fs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLDbDemo {
    public static void main(String[] args) throws SQLException {
        /*
        1) загрузить драйвер
        2) подключится к базе данных
        3) создание нужной таблицы и / или вставка данных в таблицу
        4) извлечение данных
        5) закрытие соединения (ресурс)


        DriverManager - позволяет подключиться к базе данных
        по указанному URL

        Также он загружает драйвер JDBC

        Регистрация драйвера в системе:
        1)
        Driver driver = new com.mysql.jdbc.Driver();
        DriverManager.registerDriver(driver);

        2) Class.forName("com.mysql.jdbc.Driver");

         */

        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Unable to load driver class");
            System.out.println(e.getMessage());
        }

        Connection connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/group47fs",
                "root",
                "root2023");

        if (connection.isClosed()) {
            System.out.println("Соединение закрыто");
        } else {
            System.out.println("Соединение установленно ...");
        }

        // создаем таблицу

        Statement statement = connection.createStatement();

        String sqlRequest = "CREATE TABLE employee (id INT PRIMARY KEY, name VARCHAR (255))";

        int result = statement.executeUpdate(sqlRequest);

        System.out.println("Таблица employee создана успешно? " + (result == 0));


        // добавляем данные в таблицу

        String sqlRequest1 = "INSERT INTO employee VALUE(1,'John')";
        String sqlRequest2 = "INSERT INTO employee VALUE(2,'Bill')";

        int result1 = statement.executeUpdate(sqlRequest1);
        int result2 = statement.executeUpdate(sqlRequest2);

        System.out.println("Insert first data was success: " + (result1 > 0));

        System.out.println("Insert second data was success: " + (result2 > 0));


        // закрываем все

        statement.close();
        connection.close();

    }
}
