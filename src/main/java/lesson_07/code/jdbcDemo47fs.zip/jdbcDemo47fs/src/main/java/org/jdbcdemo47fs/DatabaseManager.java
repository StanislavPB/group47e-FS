package org.jdbcdemo47fs;

import org.h2.tools.Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private Connection connection;

    public Connection getConnection() throws ClassNotFoundException, SQLException {

        if (connection == null) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                    "jdbc:h2:mem:test",
                    "sa",
                    "");
            Server.createWebServer("-web", "-webAllowOthers", "-webPort", "8082").start();
        }
        return connection;
    }


    public void createTable() throws SQLException {

        // создаем таблицу

        Statement statement = connection.createStatement();

        String sqlRequest = "CREATE TABLE authors (id INT PRIMARY KEY, name VARCHAR (255))";

        statement.execute(sqlRequest);


        // добавляем данные в таблицу

        String sqlRequest1 = "INSERT INTO authors VALUES(1,'John')";
        String sqlRequest2 = "INSERT INTO authors VALUES(2,'Bill')";

        statement.execute(sqlRequest1);
        statement.execute(sqlRequest2);



        // закрываем все

        statement.close();
    }

    public void close() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }

}
