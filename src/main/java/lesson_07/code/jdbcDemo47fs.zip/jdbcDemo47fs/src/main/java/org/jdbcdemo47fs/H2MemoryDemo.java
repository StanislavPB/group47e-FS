package org.jdbcdemo47fs;

import java.sql.SQLException;
import java.util.Scanner;

public class H2MemoryDemo {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        DatabaseManager manager = new DatabaseManager();

        manager.getConnection();
        manager.createTable();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter smt");
        String line = scanner.nextLine();

        manager.close();

    }
}
